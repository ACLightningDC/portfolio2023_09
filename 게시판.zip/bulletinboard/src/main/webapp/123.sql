CREATE TABLE IF NOT EXISTS `users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `address_id` INT NULL DEFAULT -1,
  `userid` VARCHAR(45) NOT NULL,
  `password` VARCHAR(500) NOT NULL,
  `name` NVARCHAR(45) NOT NULL,
  `date` TIMESTAMP NOT NULL DEFAULT current_timestamp,
  `phone` VARCHAR(45) NOT NULL,
  `gender` VARCHAR(1) NOT NULL,
  `email` VARCHAR(45) NULL,
  `birthday` DATE NULL,
  `grade` NVARCHAR(1) NULL DEFAULT 'N',
  PRIMARY KEY (`id`),
  UNIQUE INDEX `userid_UNIQUE` (`userid` ASC) VISIBLE,
  UNIQUE INDEX `email_UNIQUE` (`email` ASC) VISIBLE)
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8mb3;


create table users (
id number not null auto_increment,
address_id 


);


CREATE TABLE IF NOT EXISTS `inquiry` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `users_id` INT UNSIGNED NOT NULL,
  `sellerrMall_id` INT UNSIGNED NOT NULL,
  `product_id` INT UNSIGNED NOT NULL,
  `order_list_id` INT UNSIGNED NOT NULL,
  `contents` NVARCHAR(300) NULL,
  `name` NVARCHAR(45) NOT NULL,
  `date` TIMESTAMP NULL DEFAULT current_timestamp,
  `result` NVARCHAR(1) NULL DEFAULT 'N',
  `answer` NVARCHAR(300) NULL,
  PRIMARY KEY (`id`, `users_id`, `sellerrMall_id`, `product_id`, `order_list_id`),
  INDEX `fk_inquiry_users1_idx` (`users_id` ASC) VISIBLE,
  INDEX `fk_inquiry_sellerrMall1_idx` (`sellerrMall_id` ASC) VISIBLE,
  INDEX `fk_inquiry_product1_idx` (`product_id` ASC) VISIBLE,
  INDEX `fk_inquiry_order_list1_idx` (`order_list_id` ASC) VISIBLE,
  CONSTRAINT `fk_inquiry_sellerrMall1`
    FOREIGN KEY (`sellerrMall_id`)
    REFERENCES `sellermall` (`id`)
    ON DELETE CASCADE,
  CONSTRAINT `fk_inquiry_users1`
    FOREIGN KEY (`users_id`)
    REFERENCES `users` (`id`)
    ON DELETE NO ACTION,
  CONSTRAINT `fk_inquiry_product1`
    FOREIGN KEY (`product_id`)
    REFERENCES `product` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_inquiry_order_list1`
    FOREIGN KEY (`order_list_id`)
    REFERENCES `order_list` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb3;