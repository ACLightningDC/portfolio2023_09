package contactCenter;

import java.util.List;
import java.util.Map;
import java.util.Vector;
import javax.servlet.ServletContext;
import contactCenter.JDBConnect;//나중에 common으로 바꿔서 넣어야함 우선 내가 가진건 contactCenter 클래스안에있기때문에
//쿼리문들은 다 한번씩 보고 해야할꺼같음 구매한 책기준으로 적어둔거다 보니 조금더 자세히 mysql보고 설정해야할꺼같음

public class ContactCenterDAO extends JDBConnect {
	public ContactCenterDAO(ServletContext application) {
		super(application);
	}

	
	// 검색 조건에 맞는 게시물 목록을 반환합니다.
	public List<ContactCenterDTO> selectList(Map<String, Object> map) {
		List<ContactCenterDTO> contactcenter = new Vector<ContactCenterDTO>(); // 결과(게시물 목록)를 담을 변수

		String query = "SELECT * FROM inquiry";
		if (map.get("searchWord") != null) {

			query += " WHERE " + map.get("searchField") + " " + " LIKE '%" + map.get("searchWord") + "%' ";

		}
	

		try {
			stmt = con.createStatement(); // 쿼리문 생성
			rs = stmt.executeQuery(query); // 쿼리 실행

			while (rs.next()) { // 결과를 순화하며...
				// 한 행(게시물 하나)의 내용을 DTO에 저장
				ContactCenterDTO dto = new ContactCenterDTO();

				dto.setId(rs.getString("id")); // 아이디
				dto.setName(rs.getString("name")); // 제목

				dto.setDate(rs.getString("date"));
				contactcenter.add(dto); // 결과 목록에 저장
			}
		} catch (Exception e) {
			System.out.println("조회수를 가져오는데 실패함");
			e.printStackTrace();
		}

		return contactcenter;
	}

	
	

	// 검색 조건에 맞는 게시물 목록을 반환합니다(페이징 기능 지원).
	public List<ContactCenterDTO> selectListPage(Map<String, Object> map) {
		List<ContactCenterDTO> bbs = new Vector<ContactCenterDTO>(); // 결과(게시물 목록)를 담을 변수

		// 쿼리문 템플릿

		String query = " SELECT * FROM ( " + "    SELECT Tb.*, ROWNUM rNum FROM ( "
						+ "        SELECT * FROM inquiry ";

		// 검색 조건 추가
		if (map.get("searchWord") != null) {

			query += " WHERE " + map.get("searchField") + " LIKE '%" + map.get("searchWord") + "%' ";

		}

		
		try {
			// 쿼리문 완성
			psmt = con.prepareStatement(query);
			psmt.setString(1, map.get("start").toString());
			psmt.setString(2, map.get("end").toString());

			// 쿼리문 실행
			rs = psmt.executeQuery();

			while (rs.next()) {
				// 한 행(게시물 하나)의 데이터를 DTO에 저장
				ContactCenterDTO dto = new ContactCenterDTO();
				dto.setId(rs.getString("id")); // 아이디
				dto.setName(rs.getString("name")); // 제목
				dto.setDate(rs.getString("date")); //작성일
			
				// 반환할 결과 목록에 게시물 추가
				bbs.add(dto);
			}
		} catch (Exception e) {
			System.out.println("조회수를 가져오는데 실패함");
			e.printStackTrace();
		}

		// 목록 반환
		return bbs;
	}

	// 게시글 데이터를 받아 DB에 추가합니다.
	public int insertWrite(ContactCenterDTO dto) {
		int result = 0;

		try {
			// INSERT 쿼리문 작성

			String query = "INSERT INTO inquiry ( " + " id ,name , date) "
					+ " VALUES ( " + " seq_board_num.NEXTVAL, ?, ?, ?)";

			psmt = con.prepareStatement(query); // 동적 쿼리
			psmt.setString(3, dto.getDate());
			psmt.setString(2, dto.getName());
			psmt.setString(1, dto.getId());

			result = psmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("");
			e.printStackTrace();
		}

		return result;
	}

	// 지정한 게시물을 찾아 내용을 반환합니다.
	public ContactCenterDTO selectView(String num) {
		ContactCenterDTO dto = new ContactCenterDTO();

		String query = "SELECT B.*, M.name " + " FROM users M INNER JOIN inquiry B " + " ON M.id=B.id "
				+ " WHERE num=?";

		try {
			psmt = con.prepareStatement(query);
			
			rs = psmt.executeQuery(); // 쿼리 실행

			// 결과 처리
			if (rs.next()) {
				dto.setId(rs.getString("id")); // 아이디
				dto.setName(rs.getString("name")); // 제목
				dto.setDate(rs.getString("date")); //작성일
			
			}
		} catch (Exception e) {
			System.out.println("게시물 상세보기 중 예외 발생");
			e.printStackTrace();
		}

		return dto;
	}

	

	// 지정한 게시물을 수정합니다.
	public int updateEdit(ContactCenterDTO dto) {
		int result = 0;

		try {
			// 쿼리문 템플릿

			String query = "UPDATE inquiry SET " + " id=?, name=? " + " WHERE num=?";

			psmt = con.prepareStatement(query);
			psmt.setString(3, dto.getDate());
			psmt.setString(2, dto.getName());
			psmt.setString(1, dto.getId());
			// 쿼리문 실행
			result = psmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("조회수를 수정중 실패함");
			e.printStackTrace();
		}

		return result; // 결과 반환
	}

	// 지정한 게시물을 삭제합니다.
	public int deletePost(ContactCenterDTO dto) {
		int result = 0;

		try {

			String query = "DELETE FROM inquiry WHERE num=?";

			psmt = con.prepareStatement(query);
			psmt.setString(1, dto.getId());

			result = psmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("삭제중 실패함");
			e.printStackTrace();
		}

		return result; // 결과 반환
	}
}