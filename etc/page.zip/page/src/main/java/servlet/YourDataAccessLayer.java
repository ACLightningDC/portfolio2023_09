package servlet;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
public class YourDataAccessLayer {

    // 데이터 베이스 설정
    private static Connection getConnection() throws Exception {
        String url = "jdbc:mysql://localhost:3306/your_database";
        String username = "your_username";
        String password = "your_password";
        return DriverManager.getConnection(url, username, password);
    }

    // 인기상품 검색
    public static List<String> getPopularProducts() {
        List<String> popularProducts = new ArrayList<>();
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT name FROM product WHERE popularity > 3");//3번 사면 인기상품에 검색 임시니까?
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                popularProducts.add(rs.getString("name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return popularProducts;
    }

    // 인기 샵 검색
    public static List<String> getPopularMalls() {
        List<String> popularMalls = new ArrayList<>();
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT name FROM mall WHERE popularity > 3");//3번 사면 인기샵에 검색되게하는것 임시니까
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                popularMalls.add(rs.getString("name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return popularMalls;
    }
}