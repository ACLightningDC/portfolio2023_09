package servlet;



import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/popularData")
public class Servlet extends HttpServlet {
 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     // 인기상품 데이터베이스에서 검색
     List<String> popularProducts = YourDataAccessLayer.getPopularProducts();
     List<String> popularMalls = YourDataAccessLayer.getPopularMalls();

     // jsp 전달
     request.setAttribute("popularProducts", popularProducts);
     request.setAttribute("popularMalls", popularMalls);

     // jsp 요청
     request.getRequestDispatcher("shoppinghome.jsp").forward(request, response);
 }
}