package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class PopularDataBean {
    private List<String> popularProducts = new ArrayList<>();
    private List<String> popularMalls = new ArrayList<>();

    public PopularDataBean() {
        // 데이터 베이스 초기화
        fetchDataFromDatabase();
    }

    private void fetchDataFromDatabase() {
        // JDBC 데이터 가져오기
        try {
            // 데이터베이스에 연결
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb", "username", "password");

            // 인기상품 문의
            String productQuery = "SELECT name FROM product ORDER BY buycount DESC LIMIT 5";
            PreparedStatement productStatement = connection.prepareStatement(productQuery);
            ResultSet productResult = productStatement.executeQuery();

            while (productResult.next()) {
                popularProducts.add(productResult.getString("name"));
            }

            // 인기쇼핑몰 조회
            String mallQuery = "SELECT name FROM sellermall ORDER BY some_criteria LIMIT 5";
            PreparedStatement mallStatement = connection.prepareStatement(mallQuery);
            ResultSet mallResult = mallStatement.executeQuery();

            while (mallResult.next()) {
                popularMalls.add(mallResult.getString("name"));
            }

            // 소스연결 해체
            productResult.close();
            productStatement.close();
            mallResult.close();
            mallStatement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<String> getPopularProducts() {
        return popularProducts;
    }

    public List<String> getPopularMalls() {
        return popularMalls;
    }
}
